from classes import GeneticAlgorithm
from random import sample, shuffle
from functions import get_unsolved_instances
import os
import sys

parameters = []

no_solution = get_unsolved_instances()
if __name__ == "__main__":
    if int(sys.argv[1]) >= len(no_solution):
        instance = sample(no_solution, 1)[0]
    else:
        instance = no_solution[int(sys.argv[1])]

    # Instance
    if not os.path.exists("./data/diagnostics/instance" + str(instance)):
        os.makedirs("./data/diagnostics/instance" + str(instance))

    # Instantiate genetic algorithm
    algorithm = GeneticAlgorithm(save_generations=False, population_size=20,
                                 fittest_size=.1, random_size=.1, children_size=.8, penalty=100000, initial_random_factor=0, iterations=250, log_to_console=True)

    # Run instance
    print("\r\n\r\nRunning instance", instance)
    algorithm.run(instance)

